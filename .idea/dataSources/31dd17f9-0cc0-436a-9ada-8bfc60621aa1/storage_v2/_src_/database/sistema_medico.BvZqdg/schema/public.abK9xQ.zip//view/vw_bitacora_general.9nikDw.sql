create view vw_bitacora_general
            (id, fecha_hora, usuario, nombre_usuario, operacion, tabla_afectada, registro_id, ip_origen,
             datos_anteriores, datos_nuevos)
as
SELECT b.id,
       b.creado_en       AS fecha_hora,
       u.nombre_completo AS usuario,
       u.nombre_usuario,
       b.accion          AS operacion,
       b.tabla_afectada,
       b.registro_id,
       b.ip_origen,
       b.datos_anteriores,
       b.datos_nuevos
FROM log_auditoria b
         LEFT JOIN usuario u ON u.id = b.usuario_id
ORDER BY b.creado_en DESC;

alter table vw_bitacora_general
    owner to postgres;

