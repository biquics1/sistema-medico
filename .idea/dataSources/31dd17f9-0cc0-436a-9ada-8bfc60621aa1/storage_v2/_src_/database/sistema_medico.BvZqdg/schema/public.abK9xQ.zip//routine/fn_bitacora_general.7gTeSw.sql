create function fn_bitacora_general() returns trigger
    language plpgsql
as
$$
DECLARE
    v_usuario_id INTEGER;
    v_ip         VARCHAR(45);
    v_anteriores JSONB;
    v_nuevos     JSONB;
BEGIN
    -- Usuario que ejecuta la acción (viene de la sesión de la app)
    BEGIN
        v_usuario_id := NULLIF(current_setting('app.usuario_id', true), '')::INTEGER;
    EXCEPTION WHEN OTHERS THEN
        v_usuario_id := NULL;
    END;

    -- IP / origen de la petición
    v_ip := NULLIF(current_setting('app.ip_origen', true), '');

    IF (TG_OP = 'DELETE') THEN
        v_anteriores := to_jsonb(OLD);
        IF TG_TABLE_NAME = 'usuario' THEN
            v_anteriores := v_anteriores - 'password_hash';
        END IF;

        INSERT INTO log_auditoria
            (usuario_id, accion, tabla_afectada, registro_id,
             datos_anteriores, datos_nuevos, detalles, ip_origen, creado_en)
        VALUES
            (v_usuario_id, 'DELETE', TG_TABLE_NAME, OLD.id,
             v_anteriores, NULL, 'Eliminación en ' || TG_TABLE_NAME, v_ip, CURRENT_TIMESTAMP);
        RETURN OLD;

    ELSIF (TG_OP = 'UPDATE') THEN
        v_anteriores := to_jsonb(OLD);
        v_nuevos      := to_jsonb(NEW);
        IF TG_TABLE_NAME = 'usuario' THEN
            v_anteriores := v_anteriores - 'password_hash';
            v_nuevos     := v_nuevos - 'password_hash';
        END IF;

        INSERT INTO log_auditoria
            (usuario_id, accion, tabla_afectada, registro_id,
             datos_anteriores, datos_nuevos, detalles, ip_origen, creado_en)
        VALUES
            (v_usuario_id, 'UPDATE', TG_TABLE_NAME, NEW.id,
             v_anteriores, v_nuevos, 'Actualización en ' || TG_TABLE_NAME, v_ip, CURRENT_TIMESTAMP);
        RETURN NEW;

    ELSIF (TG_OP = 'INSERT') THEN
        v_nuevos := to_jsonb(NEW);
        IF TG_TABLE_NAME = 'usuario' THEN
            v_nuevos := v_nuevos - 'password_hash';
        END IF;

        INSERT INTO log_auditoria
            (usuario_id, accion, tabla_afectada, registro_id,
             datos_anteriores, datos_nuevos, detalles, ip_origen, creado_en)
        VALUES
            (v_usuario_id, 'INSERT', TG_TABLE_NAME, NEW.id,
             NULL, v_nuevos, 'Creación en ' || TG_TABLE_NAME, v_ip, CURRENT_TIMESTAMP);
        RETURN NEW;
    END IF;

    RETURN NULL;
END;
$$;

alter function fn_bitacora_general() owner to postgres;

